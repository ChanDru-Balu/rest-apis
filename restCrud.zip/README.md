##REST-API s for all:

# Initiate with Todo API:


08-03-2025:
1. app ,
2. Server connect ,
3. Crud,
4. Routes
5.Simple error handler

09-03-2025:
1. Chaining option for methods
2. sample array 

10-03-2025:
1. serverless-http
